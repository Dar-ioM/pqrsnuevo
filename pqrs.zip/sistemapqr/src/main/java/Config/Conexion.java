package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private static final String URL = "jdbc:mysql://localhost:3306/db_pqrs";
    private static final String USER = "root";
    private static final String PASS = "12345";
    private static Connection con;

    public Conexion() {} // Constructor privado para evitar instanciación

    public Connection getConnection() {
        if (con == null) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection(URL, USER, PASS);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException("Error loading MySQL driver", e);
            } catch (SQLException e) {
                throw new RuntimeException("Error connecting to database", e);
            }
        }
        return con;
    }

    public void closeConnection() {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                throw new RuntimeException("Error closing database connection", e);
            } finally {
                con = null;
            }
        }
    }

}