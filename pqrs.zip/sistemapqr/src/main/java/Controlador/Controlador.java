package Controlador;

import Modelo.Pqrs;
import Modelo.PqrsDAO;
import Modelo.Usuario;
import Modelo.UsuarioDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.List;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class Controlador extends HttpServlet {

    Usuario us = new Usuario();
    UsuarioDAO udao = new UsuarioDAO();
    Pqrs pqrs = new Pqrs();
    PqrsDAO pqrsdao = new PqrsDAO();
    int editarId;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String menu = request.getParameter("menu");
            String accion = request.getParameter("accion");

            if (menu.equals("AdminPrincipal")) {
                request.getRequestDispatcher("AdminPrincipal.jsp").forward(request, response);
            } else if (menu.equals("AdminHistorial")) {
                request.getRequestDispatcher("AdminHistorial.jsp").forward(request, response);
            } else if (menu.equals("AdminUsuarios")) {
                switch (accion) {
                    case "Listar":
                        List lista = udao.listar();
                        request.setAttribute("usuarios", lista);
                        break;
                    case "Agregar":
                        String dni = request.getParameter("txtDni");
                        String nom = request.getParameter("txtNombres");
                        String tel = request.getParameter("txtTel");
                        String correo = request.getParameter("txtEmail");
                        String usuario = request.getParameter("txtUsr");
                        String password = request.getParameter("txtPass");
                        String rol = "usuario";
                        String estado = request.getParameter("txtEst");
                        if (dni != null && nom != null && tel != null && correo != null && usuario != null && password != null && rol != null && estado != null) {
                            us.setDni(dni);
                            us.setNom(nom);
                            us.setTel(tel);
                            us.setCorreo(correo);
                            us.setUsuario(usuario);
                            us.setPassword(password);
                            us.setRol(rol);
                            us.setEstado(estado);
                            udao.agregar(us);
                            request.getRequestDispatcher("Controlador?menu=AdminUsuarios&accion=Listar").forward(request, response);

                        } else {
                            request.setAttribute("error", "Todos los campos son obligatorios.");
                        }
                        break;
                    case "Editar":
                        editarId = Integer.parseInt(request.getParameter("id"));
                        Usuario u = udao.listarId(editarId);
                        request.setAttribute("usuario", u);
                        request.getRequestDispatcher("Controlador?menu=AdminUsuarios&accion=Listar").forward(request, response);
                        break;
                    case "Actualizar":
                        String dniA = request.getParameter("txtDni");
                        String nomA = request.getParameter("txtNombres");
                        String telA = request.getParameter("txtTel");
                        String correoA = request.getParameter("txtEmail");
                        String usuarioA = request.getParameter("txtUsr");
                        String passwordA = request.getParameter("txtPass");
                        String rolA = request.getParameter("txtRol");
                        String estadoA = request.getParameter("txtEst");
                        us.setId(editarId);
                        us.setDni(dniA);
                        us.setNom(nomA);
                        us.setTel(telA);
                        us.setCorreo(correoA);
                        us.setUsuario(usuarioA);
                        us.setPassword(passwordA);
                        us.setRol(rolA);
                        us.setEstado(estadoA);
                        udao.actualizar(us);
                        request.getRequestDispatcher("Controlador?menu=AdminUsuarios&accion=Listar").forward(request, response);
                        break;
                    case "Eliminar":
                        editarId = Integer.parseInt(request.getParameter("id"));
                        udao.eliminar(editarId);
                        request.getRequestDispatcher("Controlador?menu=AdminUsuarios&accion=Listar").forward(request, response);
                        break;
                    default:
                        throw new AssertionError();
                }
                request.getRequestDispatcher("AdminUsuarios.jsp").forward(request, response);
            } else if (menu.equals("Principal")) {
                request.getRequestDispatcher("Principal.jsp").forward(request, response);
            } else if (menu.equals("Historial")) {
                request.getRequestDispatcher("Historial.jsp").forward(request, response);
            } else if (menu.equals("Solicitudes")) {
                switch (accion) {
                    case "Listar":
                        List<Pqrs> listaPqrs = pqrsdao.listarPqrs();
                        System.out.println("Tamaño de la lista: " + listaPqrs.size());
                        request.setAttribute("solicitudes", listaPqrs);
                        break;
                    case "Agregar":
                        int idUsuario = Integer.parseInt(request.getParameter("idUsuario"));
                        int idTipoSolicitud = Integer.parseInt(request.getParameter("tipoSolicitud"));
                        String motivoSolicitud = request.getParameter("motivoSolicitud");
                        String descripcion = request.getParameter("descripcion");

                        byte[] archivoPdf = null;
                        Part filePart = request.getPart("archivoPdf");
                        if (filePart != null && filePart.getSize() > 0) {
                            InputStream fileContent = filePart.getInputStream();
                            archivoPdf = fileContent.readAllBytes();
                        }

                        pqrs.setIdUsuario(idUsuario);
                        pqrs.setIdTipoSolicitud(idTipoSolicitud);
                        pqrs.setMotivoSolicitud(motivoSolicitud);
                        pqrs.setDescripcion(descripcion);
                        pqrs.setArchivoPdf(archivoPdf);
                        pqrs.setEstado("en espera");

                        try {
                            pqrsdao.agregarPqrs(pqrs);
                            request.setAttribute("message", "Solicitud agregada con éxito");
                        } catch (SQLException e) {
                            e.printStackTrace();
                            request.setAttribute("error", "Error al agregar la solicitud: " + e.getMessage());
                        }
                        request.getRequestDispatcher("Controlador?menu=Solicitudes&accion=Listar").forward(request, response);
                        break;

                    default:
                        throw new AssertionError();
                }
                request.getRequestDispatcher("Solicitudes.jsp").forward(request, response);
            }
        } catch (Exception e) {
            throw new ServletException("Error procesando solicitud", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
