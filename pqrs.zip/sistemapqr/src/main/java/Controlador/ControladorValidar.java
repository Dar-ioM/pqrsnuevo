package Controlador;

import Modelo.UsuarioDAO;
import Modelo.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class ControladorValidar extends HttpServlet {

    UsuarioDAO udao = new UsuarioDAO();
    Usuario us = new Usuario();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("menu");
        if (accion != null) {
            if (accion.equalsIgnoreCase("Ingresar")) {
                String user = request.getParameter("txtuser");
                String pass = request.getParameter("txtpass");

                // Verificar si los campos están vacíos
                if (user.isEmpty() || pass.isEmpty()) {
                    request.setAttribute("error", "Por favor, complete todos los campos");
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                    return;
                }

                us = udao.validar(user, pass);
                if (us != null && us.getUsuario() != null) {
                    if (us.getRol().equalsIgnoreCase("administrador")) {
                        request.setAttribute("usuario", us);
                        request.getRequestDispatcher("AdminPrincipal.jsp").forward(request, response);
                    } else if (us.getRol().equalsIgnoreCase("usuario")) {
                        request.setAttribute("usuario", us);
                        request.getRequestDispatcher("Principal.jsp").forward(request, response);
                    } else {
                        request.setAttribute("error", "Rol no válido");
                        request.getRequestDispatcher("index.jsp").forward(request, response);
                    }
                } else {
                    request.setAttribute("error", "Usuario o contraseña incorrectos");
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                }
            } else {
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
        } else {
            System.out.println("La variable accion es nula");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");
        if (accion != null) {
            if (accion.equalsIgnoreCase("Ingresar")) {
                String user = request.getParameter("txtuser");
                String pass = request.getParameter("txtpass");

                // Verificar si los campos están vacíos
                if (user.isEmpty() || pass.isEmpty()) {
                    request.setAttribute("error", "Por favor, complete todos los campos");
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                    return;
                }

                us = udao.validar(user, pass);
                if (us != null && us.getUsuario() != null) {
                    if (us.getRol().equalsIgnoreCase("administrador")) {
                        request.setAttribute("usuario", us);
                        request.getRequestDispatcher("AdminPrincipal.jsp").forward(request, response);
                    } else if (us.getRol().equalsIgnoreCase("usuario")) {
                        request.setAttribute("usuario", us);
                        request.getRequestDispatcher("Principal.jsp").forward(request, response);
                    } else {
                        request.setAttribute("error", "Rol no válido");
                        request.getRequestDispatcher("index.jsp").forward(request, response);
                    }
                } else {
                    request.setAttribute("error", "Usuario o contraseña incorrectos");
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                }
            } else {
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
        } else {
            System.out.println("La variable accion es nula");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
