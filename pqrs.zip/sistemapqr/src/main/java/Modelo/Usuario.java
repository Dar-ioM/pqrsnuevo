package Modelo;

public class Usuario {

    private int id;
    private String dni;
    private String nom;
    private String tel;
    private String correo;
    private String usuario;
    private String password;
    private String rol;
    private String estado;

    // Constructores
    public Usuario() {
    }

    public Usuario(String dni, String nom, String tel, String correo, String usuario, String password, String rol, String estado) {
        this.dni = dni;
        this.nom = nom;
        this.tel = tel;
        this.correo = correo;
        this.usuario = usuario;
        this.password = password;
        this.rol = rol;
        this.estado = estado;
    }

    Usuario(int id, String nom) {
        this.id = id;
        this.nom = nom;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
