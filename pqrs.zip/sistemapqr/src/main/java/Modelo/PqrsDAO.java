package Modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class PqrsDAO {

    Timestamp fechaEnvio;
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r;
    TipoSolicitud tipoSolicitud = new TipoSolicitud();
    Usuario usuario = new Usuario();

    public List<Pqrs> listarPqrs() {
        List<Pqrs> lista = new ArrayList<>();
        try {
            con = cn.getConnection();
            // Actualiza la consulta para incluir información de las tablas usuarios y tipos_solicitud
            String sql = "SELECT p.*, u.nom AS nombre_usuario, u.usuario AS username, t.descripcion AS descripcion_tipo_solicitud "
                    + "FROM pqrs p "
                    + "JOIN usuarios u ON p.id_usuario = u.id "
                    + "JOIN tipos_solicitud t ON p.id_tipo_solicitud = t.id";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Pqrs pqrs = new Pqrs();
                pqrs.setId(rs.getInt("id"));
                pqrs.setFechaEnvio(rs.getTimestamp("fecha_envio"));
                pqrs.setMotivoSolicitud(rs.getString("motivo_solicitud"));
                pqrs.setDescripcion(rs.getString("descripcion"));
                pqrs.setArchivoPdf(rs.getBytes("archivo_pdf"));
                pqrs.setEstado(rs.getString("estado"));
                pqrs.setRespuesta(rs.getString("respuesta"));
                pqrs.setFechaRespuesta(rs.getTimestamp("fecha_respuesta"));

                // Asigna la información del usuario y tipo de solicitud al objeto Pqrs
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("id_usuario"));
                usuario.setNom(rs.getString("nombre_usuario"));
                usuario.setUsuario(rs.getString("username"));
                pqrs.setUsuario(usuario);

                TipoSolicitud tipoSolicitud = new TipoSolicitud();
                tipoSolicitud.setId(rs.getInt("id_tipo_solicitud"));
                tipoSolicitud.setDescripcion(rs.getString("descripcion_tipo_solicitud"));
                pqrs.setTipoSolicitud(tipoSolicitud);

                lista.add(pqrs);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar pqrs: " + e.getMessage());
        } finally {
            cn.closeConnection();
        }
        return lista;
    }

    public void agregarPqrs(Pqrs pqrs) throws SQLException {
        String sql = "INSERT INTO pqrs (id_usuario, id_tipo_solicitud, fecha_envio, motivo_solicitud, descripcion, archivo_pdf, estado) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, pqrs.getIdUsuario());
            ps.setInt(2, pqrs.getIdTipoSolicitud());
            ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            ps.setString(4, pqrs.getMotivoSolicitud());
            ps.setString(5, pqrs.getDescripcion());
            ps.setBytes(6, pqrs.getArchivoPdf());
            ps.setString(7, "en espera");
            ps.executeUpdate();
        }
    }
}
