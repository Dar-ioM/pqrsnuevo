package Modelo;

public class TipoSolicitud {

    private int id;
    private String descripcion;

    public TipoSolicitud(int id, String descripcion) {
        this.id = id;
        this.descripcion = descripcion;
    }

    public TipoSolicitud() {
    }

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}