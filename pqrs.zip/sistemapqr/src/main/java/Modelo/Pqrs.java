package Modelo;

import java.sql.Date;
import java.sql.Timestamp;

public class Pqrs {

    private int id;
    private int idUsuario;
    private int idTipoSolicitud;
    private Timestamp fechaEnvio;
    private String motivoSolicitud;
    private String descripcion;
    private byte[] archivoPdf;
    private String estado;
    private String respuesta;
    private Timestamp fechaRespuesta;
    private TipoSolicitud tipoSolicitud;
    private Usuario usuario;

    public Pqrs() {
    }

    public Pqrs(int id, int idUsuario, int idTipoSolicitud, Timestamp fechaEnvio, String motivoSolicitud, 
                String descripcion, byte[] archivoPdf, String estado, String respuesta, Timestamp fechaRespuesta, 
                TipoSolicitud tipoSolicitud, Usuario usuario) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.idTipoSolicitud = idTipoSolicitud;
        this.fechaEnvio = fechaEnvio;
        this.motivoSolicitud = motivoSolicitud;
        this.descripcion = descripcion;
        this.archivoPdf = archivoPdf;
        this.estado = estado;
        this.respuesta = respuesta;
        this.fechaRespuesta = fechaRespuesta;
        this.tipoSolicitud = tipoSolicitud;
        this.usuario = usuario;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public int getIdTipoSolicitud() {
        return idTipoSolicitud;
    }

    public void setIdTipoSolicitud(int idTipoSolicitud) {
        this.idTipoSolicitud = idTipoSolicitud;
    }

    public TipoSolicitud getTipoSolicitud() {
        return tipoSolicitud;
    }

    public void setTipoSolicitud(TipoSolicitud tipoSolicitud) {
        this.tipoSolicitud = tipoSolicitud;
    }

    public Timestamp getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(Timestamp fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }

    public String getMotivoSolicitud() {
        return motivoSolicitud;
    }

    public void setMotivoSolicitud(String motivoSolicitud) {
        this.motivoSolicitud = motivoSolicitud;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public byte[] getArchivoPdf() {
        return archivoPdf;
    }

    public void setArchivoPdf(byte[] archivoPdf) {
        this.archivoPdf = archivoPdf;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public Timestamp getFechaRespuesta() {
        return fechaRespuesta;
    }

    public void setFechaRespuesta(Timestamp fechaRespuesta) {
        this.fechaRespuesta = fechaRespuesta;
    }
}
