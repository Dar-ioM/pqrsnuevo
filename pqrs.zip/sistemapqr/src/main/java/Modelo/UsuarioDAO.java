package Modelo;

import com.mysql.cj.Messages;
import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r;

    public Usuario validar(String usuario, String password) {
        Usuario us = new Usuario();
        String sql = "select * from usuarios where usuario=? and password=?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, password);
            rs = ps.executeQuery();
            if (rs.next()) {
                us.setId(rs.getInt("id"));
                us.setUsuario(rs.getString("usuario"));
                us.setDni(rs.getString("dni"));
                us.setNom(rs.getString("nom"));
                us.setCorreo(rs.getString("correo"));
                us.setRol(rs.getString("rol"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cn.closeConnection();
        }
        return us;
    }

    // Operaciones crud
    public List listar() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "select * from usuarios";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Usuario us = new Usuario();
                us.setId(rs.getInt("id"));
                us.setDni(rs.getString("dni"));
                us.setNom(rs.getString("nom"));
                us.setTel(rs.getString("tel")); 
                us.setCorreo(rs.getString("correo"));
                us.setUsuario(rs.getString("usuario"));
                us.setPassword(rs.getString("password"));
                us.setRol(rs.getString("rol"));
                us.setEstado(rs.getString("estado"));
                lista.add(us);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                cn.closeConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public int agregar(Usuario us) {
        String sql = "INSERT INTO usuarios (dni, nom, tel, correo, usuario, password, rol, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, us.getDni());
            ps.setString(2, us.getNom());
            ps.setString(3, us.getTel());
            ps.setString(4, us.getCorreo());
            ps.setString(5, us.getUsuario());
            ps.setString(6, us.getPassword());
            ps.setString(7, us.getRol());
            ps.setString(8, us.getEstado());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return r;
    }

    public int actualizar(Usuario us) {
        String sql = "UPDATE usuarios SET dni=?, nom=?, tel=?, correo=?, usuario=?, password=?, rol=?, estado=? WHERE id=?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, us.getDni());
            ps.setString(2, us.getNom());
            ps.setString(3, us.getTel());
            ps.setString(4, us.getCorreo());
            ps.setString(5, us.getUsuario());
            ps.setString(6, us.getPassword());
            ps.setString(7, us.getRol());
            ps.setString(8, us.getEstado());
            ps.setInt(9, us.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return r;
    }

    public Usuario listarId(int id) {
        Usuario usr = new Usuario();
        String sql = "SELECT * FROM usuarios WHERE id="+id;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                usr.setId(rs.getInt("id"));
                usr.setDni(rs.getString("dni"));
                usr.setNom(rs.getString("nom"));
                usr.setTel(rs.getString("tel"));
                usr.setCorreo(rs.getString("correo"));
                usr.setUsuario(rs.getString("usuario"));
                usr.setPassword(rs.getString("password"));
                usr.setRol(rs.getString("rol"));
                usr.setEstado(rs.getString("estado"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usr;
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM usuarios WHERE id=" + id;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

}
